<?php

namespace App\Http\Controllers;

use App\Models\Email_account;
use Illuminate\Http\Request;

class EmailAccountController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Email_account $email_account)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Email_account $email_account)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Email_account $email_account)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Email_account $email_account)
    {
        //
    }
}
