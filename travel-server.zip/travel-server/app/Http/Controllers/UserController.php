<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    //
        public function index()
    {
        //
    $users  = User::orderBy('created_at', 'desc')->get();
     return response()->json([
            'status' => true,
            'data' => $users
        ]);    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $validation = Validator::make($request->all(), [
            'first_name' => 'required|max:255',
            'last_name' => 'required|max:255',
            'user_name' => 'required|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6|confirmed',
            'phone' => 'required',
            'address' => 'required',
            'date_of_birth' => 'required|date',
            'bio' => 'min:10|max:100',
            'role_id' => 'required|integer'
        ]);


        // check if validation fails
        if ($validation->fails()) {
           response()->json([
            'status' => false,
            'error' => $validation->errors()
        ]);}
     
        
        $user = new User();
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->user_name = $request->user_name;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->phone = $request->phone;
        $user->address = $request->address;
        $user->date_of_birth = $request->date_of_birth;
        $user->avatar_url = $request->avatar_url;
        $user->role_id = $request->role_id;
        $user->save();
      
       return response()->json([
            'status' => true,
            'message' => 'User Add Successfully'
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(ToDo $toDo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ToDo $toDo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ToDo $toDo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
         // finnd the service by id
        $todo = ToDo::find($id);
        if($todo == null){
            return response()->json([
                'status' => false,
                'message' => 'Error Task Not Found'
            ]);
        }
        // if id of serive is not null
        $todo->delete();
        return response()->json([
            'status' => true,
            'message' => 'Task Deleted Successfully'
        ]);
        
        
    }
}
