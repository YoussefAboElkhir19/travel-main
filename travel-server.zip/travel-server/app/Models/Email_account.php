<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Email_account extends Model
{
    //
}
