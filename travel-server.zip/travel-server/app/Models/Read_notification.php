<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Read_notification extends Model
{
    //
}
