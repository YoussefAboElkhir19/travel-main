<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Email</title>
</head>
<body>

<h2>You have recived from youssef</h2>
<p> Name : {{ $Maildata['name'] }}</p>
<p> Email : {{ $Maildata['email']}}</p>
<p> Subject : {{ $Maildata['subject']}}</p>
<p> Message : {{ $Maildata['message'] }}</p>
    
</body>
</html>