<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Email</title>
</head>
<body>

<h2>You have recived from youssef</h2>
<p> Name : <?php echo e($Maildata['name']); ?></p>
<p> Email : <?php echo e($Maildata['email']); ?></p>
<p> Subject : <?php echo e($Maildata['subject']); ?></p>
<p> Message : <?php echo e($Maildata['message']); ?></p>
    
</body>
</html><?php /**PATH G:\BackEnd\backend\resources\views/email/contact.blade.php ENDPATH**/ ?>