<?php

namespace App\Http\Controllers;

use App\Models\read_notifications;
use App\Http\Requests\Storeread_notificationsRequest;
use App\Http\Requests\Updateread_notificationsRequest;

class ReadNotificationsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Storeread_notificationsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(read_notifications $read_notifications)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(read_notifications $read_notifications)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Updateread_notificationsRequest $request, read_notifications $read_notifications)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(read_notifications $read_notifications)
    {
        //
    }
}
