<?php

namespace App\Http\Controllers;

use App\Models\shifts;
use App\Http\Requests\StoreshiftsRequest;
use App\Http\Requests\UpdateshiftsRequest;

class ShiftsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreshiftsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(shifts $shifts)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(shifts $shifts)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateshiftsRequest $request, shifts $shifts)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(shifts $shifts)
    {
        //
    }
}
